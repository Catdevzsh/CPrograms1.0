// Hello World
// [Flames LLC 20XX] - [C] [AI Rights reserved] - [Flames X]

#include <stdio.h>

int main() {
    printf("Hello, World!\n");
    return 0;
}